import React from "react"
import PrescriptionForm from "../../../Component/Prescription/PrescriptionForm";

export default function Prescription(){
    return(
        <div>
            <PrescriptionForm/>

        </div>
);
}

