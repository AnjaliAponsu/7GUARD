import React from 'react';
import AdministrativeNav from '../../../Component/Nav/AdministrativeNav';

const DoctorView = () => {
  return (
    <div>
      <AdministrativeNav/>
    </div>
  );
}

export default DoctorView;
