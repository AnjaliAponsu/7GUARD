import React from 'react'
import Admin_Channeling_Manage from '../../../Component/Channeling/Admin_Channeling_Manage';
import ReceptionistNavBar from '../../../Component/Nav/ReceptionistNavBar';

export default function AdminChannelingManage() {
  return (
    <div>
      <ReceptionistNavBar></ReceptionistNavBar>
      <Admin_Channeling_Manage/>
      
        
        </div>
   
  );
}
