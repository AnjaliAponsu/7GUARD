import React from 'react'
import Admin_channel_token from '../../../Component/Channeling/Admin_channel_token';


export default function AdminChannelingToken() {
  return (
    <div>
      <Admin_channel_token></Admin_channel_token>
      
        
        </div>
   
  );
}
