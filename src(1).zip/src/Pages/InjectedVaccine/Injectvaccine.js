import React from "react"
import Inject_vaccine from '../../Component/InjectedVaccine/Inject_vaccine';

export default function Injectvaccine(){
    return(
        <div>
            <Inject_vaccine/>

        </div>
);
}

