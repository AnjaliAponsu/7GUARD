import React from 'react';
import './StaffHome.css'

const StaffHome = () => {
  return (
    
    <div >
      <h1 className='ha5' style={{marginTop:'30vh'}}>Santa Dora Hospital</h1>
    </div>

  );
}

export default StaffHome;
