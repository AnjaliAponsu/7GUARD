import { useEffect, useState } from "react";
import React from "react";
import {Box, Table, TableBody, TableCell, TableHead, TableRow, Button, TextField} from "@mui/material";
import { Link } from "react-router-dom";
import AdministrativeNav from "../Nav/AdministrativeNav";

const DoctorDetails = () => {
    const [rows, setRows] = useState([]);
    const [filteredRows, setFilteredRows] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        fetchDoctors();
    }, []);

    useEffect(() => {
        handleSearch();
    }, [searchQuery, rows]);
    
    const fetchDoctors = () => {
        fetch('http://localhost:8080/api/v1/getAllDoctors', {
            method: 'GET',
            credentials: 'include',
            
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            setRows(data); // Update the rows state with fetched data
            setFilteredRows(data); // Initialize filteredRows with fetched data
        })
        .catch(error => {
            setError('Failed to fetch data'); // Set an error message if the fetch fails
            console.error('Fetch error:', error);
        });
    };

    const handleSearch = () => {
        const query = searchQuery.toLowerCase();
        const filtered = rows.filter(row => 
            row.d_nic.toString().toLowerCase().includes(query)
        );
        setFilteredRows(filtered); // Update filteredRows based on search
    };
    

    return (
        <div className="DoctorDetails">
            <AdministrativeNav/>
            <div className="header">
                <h1>Doctors Details</h1>
                <Link to={"/DoctorRegister"} className="btn vbtn mb-2">Add Doctor</Link>
            </div>
            
            <div className="search">
                <Box sx={{ display: 'flex', justifyContent: 'right', mb: 2, padding: '1%' }}>
                    <TextField
                        label="Search by NIC"
                        variant="outlined"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        sx={{ width: '20%' }}
                    />
                </Box>
            </div>

        <div className="table">
        <Table className='table table-bordered table-hover shadow container'>
            <TableHead>
                <TableRow className='text-center'>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Doctor ID</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Full Name</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>NIC</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Mobile Number-Personal</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Mobile Number-Work</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Email-Personal</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Email-Work</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Department</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>specialization</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>License Number</TableCell>
                    <TableCell style={{ fontWeight: 'bold', fontSize: '15px' }}>Status</TableCell>
                </TableRow>
            </TableHead>
            <TableBody className='text-center'>
            {error ? (
                <TableRow>
                    <TableCell colSpan={12} align="center">{error}</TableCell>
                </TableRow>
            ) : (
                filteredRows.length > 0 ? filteredRows.map(row => (
                    <TableRow key={row.d_id || indexedDB}>
                        <TableCell>{row?.d_id}</TableCell>
                        <TableCell>{row?.docFullName}</TableCell>
                        <TableCell>{row?.d_nic}</TableCell>
                        <TableCell>{row?.d_mobileNumber}</TableCell>
                        <TableCell>{row?.d_workNumber}</TableCell>
                        <TableCell>{row?.d_personalEmail}</TableCell>
                        <TableCell>{row?.doctorWorkEmail}</TableCell>
                        <TableCell>{row?.d_department}</TableCell>
                        <TableCell>{row?.d_specialization}</TableCell>
                        <TableCell>{row?.d_licenseNumber}</TableCell>
                        <TableCell>{row?.d_status}</TableCell>
                        <TableCell>
                        <Link to={`/UpdateDoctor/${row.d_id}`} className="btn btn-primary">Edit</Link>
                        </TableCell>
                    </TableRow>
                )) : (
                    <TableRow>
                        <TableCell colSpan={12} align="center">No Data</TableCell>
                    </TableRow>
                )
            )}
        </TableBody>
    </Table>
    </div>
    </div>
    );
}

export default DoctorDetails;
