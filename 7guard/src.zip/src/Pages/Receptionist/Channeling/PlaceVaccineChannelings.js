
import React from 'react'
import Vaccine_channeling_Form from '../../../Component/Channeling/Vaccine_channeling_Form';


export default function PlaceVaccineChannelings() {
  return (
    <div>
      <Vaccine_channeling_Form/>
      
        
        </div>
   
  );
}
