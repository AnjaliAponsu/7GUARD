import React from 'react'
import Edit_vaccine_channeling from '../../../Component/Channeling/Edit_vaccine_channeling';


export default function EditVaccineChanneling() {
  return (
    <div>
      <Edit_vaccine_channeling></Edit_vaccine_channeling>
      
        
        </div>
   
  );
}
