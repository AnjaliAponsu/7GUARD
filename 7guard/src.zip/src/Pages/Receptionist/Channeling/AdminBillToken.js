import React from 'react'
import Admin_Bill_Token from '../../../Component/Channeling/Admin_Bill_Token';


export default function AdminBillToken() {
  return (
    <div>
      <Admin_Bill_Token></Admin_Bill_Token>
      
        
        </div>
   
  );
}
