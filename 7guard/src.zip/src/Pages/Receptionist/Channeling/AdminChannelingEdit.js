import React from 'react'
import Admin_Channeling_Edit from '../../../Component/Channeling/Admin_Channeling_Edit';

export default function AdminChannelingEdit() {
  return (
    <div>
      <Admin_Channeling_Edit></Admin_Channeling_Edit>
    </div>
   
  );
}
