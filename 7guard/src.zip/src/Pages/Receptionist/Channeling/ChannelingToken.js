import React from 'react'
import Channeling_token from '../../../Component/Channeling/Channeling_token';


export default function ChannelingToken() {
  return (
    <div>
      <Channeling_token></Channeling_token>
      
        
        </div>
   
  );
}
