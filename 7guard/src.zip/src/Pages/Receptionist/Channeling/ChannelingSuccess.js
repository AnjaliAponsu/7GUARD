import React from 'react'
import Channeling_Success from '../../../Component/Channeling/Channeling_Success';


export default function ChannelingSuccess() {
  return (
    <div>
      <Channeling_Success></Channeling_Success>
      
        
        </div>
   
  );
}
